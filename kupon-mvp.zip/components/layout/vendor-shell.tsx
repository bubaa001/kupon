'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  BadgeDollarSign,
  ClipboardCheck,
  Home,
  LogOut,
  Store,
  UtensilsCrossed,
  Wallet,
} from 'lucide-react';
import { Logo } from '@/components/ui/logo';
import { Avatar } from '@/components/ui/avatar';
import { cn, formatTZS } from '@/lib/utils';
import { signOut } from '@/lib/logout';

const NAV = [
  { href: '/vendor', label: 'Home', icon: Home },
  { href: '/vendor/sales', label: 'Sales', icon: BadgeDollarSign },
  { href: '/vendor/scan', label: 'Orders', icon: ClipboardCheck, primary: true },
  { href: '/vendor/menu', label: 'Menu', icon: UtensilsCrossed },
  { href: '/vendor/settlement', label: 'Settlement', icon: Wallet },
];

export type VendorShellUser = {
  name: string;
  vendorName: string;
  vendorCode: string;
  universityName: string;
  universityCode: string;
  pendingBalance: number;
};

function isActive(pathname: string, href: string) {
  if (href === '/vendor') return pathname === '/vendor';
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function VendorShell({
  user,
  children,
}: {
  user: VendorShellUser;
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-dvh bg-canvas">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col overflow-hidden bg-navy px-4 py-6 lg:flex">
        <div className="pointer-events-none absolute -left-16 bottom-10 h-56 w-56 rounded-full bg-emerald-500/10 blur-3xl" />
        <Logo href="/vendor" variant="light" className="relative px-2" />

        <div className="relative mt-8 flex-1">
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
            Vendor terminal
          </p>
          <nav className="space-y-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = isActive(pathname, item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex min-h-[44px] items-center gap-3 rounded-xl px-3 text-sm font-medium transition-all',
                    active
                      ? 'bg-white/10 text-white shadow-sm'
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-100',
                  )}
                >
                  <span
                    className={cn(
                      'flex h-8 w-8 items-center justify-center rounded-lg transition-colors',
                      active ? 'bg-primary-500 text-white' : 'bg-white/5 text-slate-400',
                    )}
                  >
                    <Icon className="h-4 w-4" />
                  </span>
                  {item.label === 'Orders' ? 'Orders & coupons' : item.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.06] p-4 backdrop-blur">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.15em] text-primary-300">
              <Store className="h-3.5 w-3.5" />
              Pending settlement
            </div>
            <p className="mt-2 text-xl font-semibold tracking-tight text-white tabular">
              {formatTZS(user.pendingBalance)}
            </p>
            <Link
              href="/vendor/settlement"
              className="mt-3 inline-flex min-h-[36px] w-full items-center justify-center rounded-lg border border-white/15 bg-white/5 px-3 text-xs font-semibold text-white transition-colors hover:bg-white/10"
            >
              View settlements
            </Link>
          </div>
        </div>

        <div className="relative mt-4 border-t border-white/10 pt-4">
          <div className="flex items-center gap-3 px-1">
            <Avatar name={user.vendorName} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{user.vendorName}</p>
              <p className="truncate text-[10px] text-slate-500">{user.vendorCode}</p>
            </div>
            <button
              type="button"
              onClick={() => void signOut()}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-white/90 backdrop-blur-md lg:hidden">
          <div className="mx-auto flex h-16 max-w-md items-center justify-between px-4">
            <Logo href="/vendor" size="sm" />
            <div className="flex items-center gap-2">
              <span className="inline-flex max-w-[130px] items-center gap-1 truncate rounded-full border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] font-semibold text-emerald-700">
                <Store className="h-3 w-3 shrink-0" />
                <span className="truncate">{user.vendorName}</span>
              </span>
              <Avatar name={user.vendorName} size="sm" />
            </div>
          </div>
        </header>

        <header className="hidden h-16 items-center justify-between border-b border-slate-200/70 bg-white/70 px-8 backdrop-blur lg:flex">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-medium text-slate-700">{user.universityName}</span>
            <span className="text-slate-300">/</span>
            <span>{user.vendorName}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[10px] font-semibold text-emerald-700">
              Terminal online
            </span>
            <span className="hidden rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10px] font-semibold text-slate-500 sm:inline">
              {user.vendorCode}
            </span>
          </div>
        </header>

        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-12 lg:pt-8">
          {children}
        </main>

        <nav
          className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200/80 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden"
          aria-label="Vendor navigation"
        >
          <div className="mx-auto grid h-[68px] max-w-md grid-cols-5 items-center px-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = isActive(pathname, item.href);
              if (item.primary) {
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex h-full flex-col items-center justify-center"
                  >
                    <span
                      className={cn(
                        'flex h-12 w-12 -translate-y-3 items-center justify-center rounded-2xl border-4 border-white text-white shadow-lg shadow-emerald-500/30 transition-transform active:scale-95',
                        active ? 'bg-primary-600' : 'bg-primary-500',
                      )}
                    >
                      <Icon className="h-5 w-5" strokeWidth={2.4} />
                    </span>
                    <span
                      className={cn(
                        '-mt-2 text-[10px] font-semibold',
                        active ? 'text-primary-700' : 'text-slate-500',
                      )}
                    >
                      {item.label}
                    </span>
                  </Link>
                );
              }
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="flex h-full flex-col items-center justify-center gap-1"
                >
                  <Icon
                    className={cn(
                      'h-[21px] w-[21px] transition-colors',
                      active ? 'text-primary-600' : 'text-slate-400',
                    )}
                    strokeWidth={active ? 2.4 : 2}
                  />
                  <span
                    className={cn(
                      'text-[10px] font-medium',
                      active ? 'text-primary-700' : 'text-slate-500',
                    )}
                  >
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
