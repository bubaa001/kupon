'use client';

import { useMemo, useState } from 'react';
import {
  CheckCircle2,
  ListChecks,
  RefreshCw,
  RotateCcw,
  SearchX,
  XCircle,
} from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/ui/page-header';
import { PageSkeleton } from '@/components/ui/skeleton';
import { RefundStatusBadge } from '@/components/ui/status-badge';
import { StatCard } from '@/components/ui/stat-card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatTZS, relativeTime } from '@/lib/utils';
import type { RefundListData, RefundRow } from '../_components/types';
import { queryString, useApiData } from '../_components/hooks';
import { RefundDetailDialog, RefundReviewDialog } from '../_components/refund-dialogs';
import { RangeTabs, SectionCard, TableEmpty } from '../_components/ui-bits';

type StatusFilter = 'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED';

const STATUS_OPTIONS: { value: StatusFilter; label: string }[] = [
  { value: 'ALL', label: 'All requests' },
  { value: 'PENDING', label: 'Pending' },
  { value: 'APPROVED', label: 'Approved' },
  { value: 'REJECTED', label: 'Rejected' },
];

export default function AdminRefundsPage() {
  const [status, setStatus] = useState<StatusFilter>('ALL');
  const [reviewRefund, setReviewRefund] = useState<RefundRow | null>(null);
  const [detailRefund, setDetailRefund] = useState<RefundRow | null>(null);

  const url = useMemo(
    () =>
      `/api/admin/refunds${queryString({
        status: status === 'ALL' ? undefined : status,
      })}`,
    [status],
  );
  const { data, error, loading, reload } = useApiData<RefundListData>(url);
  const requests = data?.requests ?? [];

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Student payouts"
        title="Refunds"
        description="Review unused-balance refund requests. Approving moves money to the student's mobile wallet and is fully audited."
        actions={
          <Button type="button" variant="outline" size="sm" onClick={reload} disabled={loading}>
            <RefreshCw className={loading ? 'h-4 w-4 animate-spin' : 'h-4 w-4'} />
            <span className="hidden sm:inline">Refresh</span>
          </Button>
        }
      />

      {error ? (
        <Alert variant="danger" title="Could not load refund requests">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span>{error}</span>
            <Button type="button" size="sm" variant="outline" onClick={reload}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      {loading && !data ? (
        <PageSkeleton />
      ) : error && !data ? null : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
              label="Pending review"
              value={data ? String(data.summary.pending) : '—'}
              icon={RotateCcw}
              accent="amber"
              hint={
                data ? `${formatTZS(data.summary.pendingAmount)} requested` : 'Loading…'
              }
            />
            <StatCard
              label="Approved"
              value={data ? String(data.summary.approved) : '—'}
              icon={CheckCircle2}
              accent="emerald"
              hint={data ? `${formatTZS(data.summary.approvedAmount)} paid out` : 'Loading…'}
            />
            <StatCard
              label="Rejected"
              value={data ? String(data.summary.rejected) : '—'}
              icon={XCircle}
              accent="rose"
              hint={
                data ? `${formatTZS(data.summary.rejectedAmount)} kept in wallets` : 'Loading…'
              }
            />
            <StatCard
              label="All requests"
              value={data ? String(data.summary.total) : '—'}
              icon={ListChecks}
              accent="sky"
              hint="Every request ever filed"
            />
          </div>

          <SectionCard contentClassName="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <RangeTabs value={status} onChange={setStatus} options={STATUS_OPTIONS} />
              <p className="text-[11px] text-slate-400">
                Pending requests are reviewed oldest first in the queue.
              </p>
            </div>

            {requests.length > 0 ? (
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <Table className="min-w-[860px]">
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead>Reference</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Requested</TableHead>
                      <TableHead>Reviewed</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {requests.map((refund) => (
                      <TableRow key={refund.id}>
                        <TableCell>
                          <p className="font-mono text-[11px] font-semibold text-slate-700">
                            {refund.reference}
                          </p>
                        </TableCell>
                        <TableCell>
                          <p className="text-xs font-medium text-slate-800">
                            {refund.student.name}
                          </p>
                          <p className="font-mono text-[10px] text-slate-400">
                            {refund.student.studentId}
                          </p>
                        </TableCell>
                        <TableCell className="text-right">
                          <span className="text-xs font-semibold tabular text-slate-900">
                            {formatTZS(refund.amount)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <p className="max-w-[240px] truncate text-[11px] text-slate-600">
                            {refund.reason}
                          </p>
                        </TableCell>
                        <TableCell>
                          <RefundStatusBadge status={refund.status} />
                        </TableCell>
                        <TableCell>
                          <span className="text-[11px] text-slate-500">
                            {relativeTime(refund.createdAt)}
                          </span>
                        </TableCell>
                        <TableCell>
                          {refund.reviewedBy ? (
                            <div>
                              <p className="text-[11px] text-slate-600">{refund.reviewedBy}</p>
                              <p className="text-[10px] text-slate-400">
                                {refund.reviewedAt ? relativeTime(refund.reviewedAt) : ''}
                              </p>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end">
                            {refund.status === 'PENDING' ? (
                              <Button
                                type="button"
                                size="sm"
                                onClick={() => setReviewRefund(refund)}
                              >
                                Review
                              </Button>
                            ) : (
                              <Button
                                type="button"
                                size="sm"
                                variant="ghost"
                                onClick={() => setDetailRefund(refund)}
                              >
                                Details
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <TableEmpty
                icon={status === 'PENDING' ? CheckCircle2 : SearchX}
                title={
                  status === 'PENDING'
                    ? 'Inbox zero — no refunds waiting'
                    : 'No refund requests here'
                }
                description={
                  status === 'PENDING'
                    ? 'Every request has been reviewed. New ones will appear here immediately.'
                    : 'When students ask for unused balance back, their requests land in this queue.'
                }
                action={
                  status !== 'ALL' ? (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setStatus('ALL')}
                    >
                      View all requests
                    </Button>
                  ) : undefined
                }
              />
            )}
          </SectionCard>
        </>
      )}

      <RefundReviewDialog
        refund={reviewRefund}
        open={Boolean(reviewRefund)}
        onOpenChange={(open) => {
          if (!open) setReviewRefund(null);
        }}
        onReviewed={reload}
      />

      <RefundDetailDialog
        refund={detailRefund}
        open={Boolean(detailRefund)}
        onOpenChange={(open) => {
          if (!open) setDetailRefund(null);
        }}
      />
    </div>
  );
}
