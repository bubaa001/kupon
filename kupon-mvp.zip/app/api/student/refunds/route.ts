import { prisma } from '@/lib/db';
import { fail, ok, parseJson } from '@/lib/api';
import { conflict, notFound, tooManyRequests } from '@/lib/errors';
import { rateLimit } from '@/lib/rate-limit';
import { refundRequestSchema } from '@/lib/validators';
import { snippeMock } from '@/lib/payments/snippe';
import { formatTZS, randomReference } from '@/lib/utils';
import type { RefundCreated, RefundsData } from '@/app/student/_lib/types';
import { getStudentBalance, getStudentContext, serializeRefund } from '../_lib/student';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Minimum refund amount, mirroring `refundRequestSchema`. */
const MIN_REFUND = 1000;

/**
 * GET /api/student/refunds
 *
 * Balances plus this student's refund history. `eligibleAmount` is what they can
 * request right now: zero while an older request is still PENDING (admins review
 * one request per student at a time) and zero below the TZS 1,000 minimum.
 */
export async function GET() {
  try {
    const { student } = await getStudentContext();
    await snippeMock.settleStaleTopUps(student.id);

    const [requests, balance] = await Promise.all([
      prisma.refundRequest.findMany({
        where: { studentId: student.id },
        orderBy: { createdAt: 'desc' },
        take: 50,
      }),
      getStudentBalance(student.id),
    ]);

    const hasPending = requests.some((request) => request.status === 'PENDING');
    const eligibleAmount = hasPending ? 0 : balance >= MIN_REFUND ? balance : 0;

    const data: RefundsData = {
      requests: requests.map(serializeRefund),
      balance,
      eligibleAmount,
      hasPending,
    };

    return ok(data);
  } catch (error) {
    return fail(error);
  }
}

/**
 * POST /api/student/refunds
 *
 * Records a refund *request* only. Money never moves here: an admin reviews and
 * approves it, and only then does the payment provider pay the student out.
 */
export async function POST(request: Request) {
  try {
    const { user, student } = await getStudentContext();

    const limit = rateLimit(`student:refund:${user.id}`, 5, 10 * 60_000);
    if (!limit.allowed) {
      throw tooManyRequests(
        'Too many refund requests. Please wait a few minutes before trying again.',
        limit.retryAfterSeconds,
      );
    }

    const body = await parseJson(request, refundRequestSchema);
    await snippeMock.settleStaleTopUps(student.id);

    const [profile, pending] = await Promise.all([
      prisma.studentProfile.findUnique({
        where: { id: student.id },
        select: {
          universityId: true,
          walletBalance: true,
          wallet: { select: { balance: true } },
        },
      }),
      prisma.refundRequest.findFirst({
        where: { studentId: student.id, status: 'PENDING' },
      }),
    ]);

    if (!profile) throw notFound('Student wallet not found.');
    const balance = profile.wallet?.balance ?? profile.walletBalance;

    if (pending) {
      throw conflict(
        'You already have a refund request awaiting review. Wait for the admin decision before requesting again.',
        { requestId: pending.id, amount: pending.amount },
      );
    }

    if (body.amount > balance) {
      throw conflict(
        `A refund cannot exceed your available balance of ${formatTZS(balance)}.`,
        { available: balance, requested: body.amount },
      );
    }

    const created = await prisma.refundRequest.create({
      data: {
        reference: randomReference('RFD'),
        studentId: student.id,
        universityId: profile.universityId,
        amount: body.amount,
        reason: body.reason,
        status: 'PENDING',
      },
    });

    const data: RefundCreated = {
      request: serializeRefund(created),
      message:
        'Ombi lako limewasilishwa. Admin wa chuo atalipitia na utapata taarifa kwenye simu yako.',
    };

    return ok(data);
  } catch (error) {
    return fail(error);
  }
}
