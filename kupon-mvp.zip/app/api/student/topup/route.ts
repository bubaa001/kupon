import { z } from 'zod';
import { prisma } from '@/lib/db';
import { fail, ok, parseJson, searchParams } from '@/lib/api';
import { badRequest, notFound, tooManyRequests } from '@/lib/errors';
import { getPaymentProvider } from '@/lib/payments';
import { snippeMock } from '@/lib/payments/snippe';
import { rateLimit } from '@/lib/rate-limit';
import { topUpSchema } from '@/lib/validators';
import type { TopUpCreated, TopUpStatusData } from '@/app/student/_lib/types';
import { getStudentBalance, getStudentContext } from '../_lib/student';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const idSchema = z.object({ id: z.string().trim().min(1, 'Top-up reference is required') });

/**
 * POST /api/student/topup
 *
 * Creates a PENDING mobile-money collection through the configured payment
 * provider. The wallet is only credited by the provider's settlement path (the
 * mock settles after ~2s, or lazily on the next wallet read).
 */
export async function POST(request: Request) {
  try {
    const { user, student } = await getStudentContext();
    if (!user.universityId) {
      throw badRequest('Your account is not linked to a university.');
    }

    const limit = rateLimit(`student:topup:${user.id}`, 5, 60_000);
    if (!limit.allowed) {
      throw tooManyRequests(
        'Too many top-up attempts. Please wait a minute and try again.',
        limit.retryAfterSeconds,
      );
    }

    const body = await parseJson(request, topUpSchema);
    const result = await getPaymentProvider().initiateTopUp({
      universityId: user.universityId,
      studentProfileId: student.id,
      amount: body.amount,
      phone: body.phone ?? user.phone,
      network: body.network,
    });

    const data: TopUpCreated = {
      transactionId: result.transactionId,
      reference: result.reference,
      status: 'PENDING',
      routeCode: result.routeCode,
      message: result.message,
      aggregatorFee: result.aggregatorFee,
    };

    return ok(data);
  } catch (error) {
    return fail(error);
  }
}

/**
 * GET /api/student/topup?id=
 *
 * Polled by the top-up screen. Lazily settles stale mock top-ups so the UI
 * reaches the success state even if the in-process timer was frozen.
 */
export async function GET(request: Request) {
  try {
    const { student } = await getStudentContext();
    const params = searchParams(request);
    const { id } = idSchema.parse({ id: params.get('id') ?? '' });

    await snippeMock.settleStaleTopUps(student.id);

    const [transaction, balance] = await Promise.all([
      prisma.transaction.findFirst({
        where: { id, studentId: student.id, type: 'TOPUP' },
      }),
      getStudentBalance(student.id),
    ]);

    if (!transaction) throw notFound('This top-up was not found.');

    const data: TopUpStatusData = {
      transaction: {
        id: transaction.id,
        reference: transaction.reference,
        amount: transaction.amount,
        status: transaction.status as TopUpStatusData['transaction']['status'],
        network: transaction.network,
        createdAt: transaction.createdAt.toISOString(),
        settledAt: transaction.settledAt?.toISOString() ?? null,
      },
      balance,
    };

    return ok(data);
  } catch (error) {
    return fail(error);
  }
}
