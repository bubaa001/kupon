import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { fail, ok } from '@/lib/api';
import { tenantWhere } from '@/lib/tenant';
import { parseQuery, requireAdmin } from '../_lib/scope';
import { refundInclude, serializeRefund } from '../_lib/refunds';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const refundsQuerySchema = z.object({
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']).optional(),
  universityId: z.string().min(1).optional(),
});

export async function GET(request: Request) {
  try {
    const user = await requireAdmin();
    const query = parseQuery(request, refundsQuerySchema);
    const tenant = tenantWhere(user, query.universityId);

    const where: Prisma.RefundRequestWhereInput = { ...tenant };
    if (query.status) where.status = query.status;

    const [requests, grouped] = await Promise.all([
      prisma.refundRequest.findMany({
        where,
        include: refundInclude,
        orderBy: { createdAt: 'desc' },
        take: 200,
      }),
      prisma.refundRequest.groupBy({
        by: ['status'],
        where: tenant,
        _sum: { amount: true },
        _count: { _all: true },
      }),
    ]);

    const counts: Record<string, number> = { PENDING: 0, APPROVED: 0, REJECTED: 0 };
    const amounts: Record<string, number> = { PENDING: 0, APPROVED: 0, REJECTED: 0 };
    for (const row of grouped) {
      counts[row.status] = row._count._all;
      amounts[row.status] = row._sum.amount ?? 0;
    }

    // Pending first: that is the admin's work queue.
    const rows = requests
      .map(serializeRefund)
      .sort((a, b) =>
        a.status === 'PENDING' && b.status !== 'PENDING'
          ? -1
          : b.status === 'PENDING' && a.status !== 'PENDING'
            ? 1
            : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );

    return ok({
      requests: rows,
      summary: {
        pending: counts.PENDING,
        approved: counts.APPROVED,
        rejected: counts.REJECTED,
        total: counts.PENDING + counts.APPROVED + counts.REJECTED,
        pendingAmount: amounts.PENDING,
        approvedAmount: amounts.APPROVED,
        rejectedAmount: amounts.REJECTED,
      },
    });
  } catch (error) {
    return fail(error);
  }
}
