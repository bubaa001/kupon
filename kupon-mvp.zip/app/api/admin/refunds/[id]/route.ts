import { prisma } from '@/lib/db';
import { fail, ok, parseJson } from '@/lib/api';
import { auditLog } from '@/lib/audit';
import { conflict, notFound } from '@/lib/errors';
import { getPaymentProvider } from '@/lib/payments';
import type { RefundResult } from '@/lib/payments/types';
import { refundDecisionSchema } from '@/lib/validators';
import { tenantWhere } from '@/lib/tenant';
import { requireAdmin } from '../../_lib/scope';
import { refundInclude, serializeRefund } from '../../_lib/refunds';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Review a refund request.
 *
 * APPROVED  → claim the request, call `getPaymentProvider().initiateRefund()`
 *             (which debits the wallet and books a REFUND ledger transaction),
 *             then write an audit entry. If the payout fails, the claim is
 *             reverted so the request stays in the queue.
 * REJECTED  → claim, store the reviewer + note, audit. No money moves.
 */
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin();
    const body = await parseJson(request, refundDecisionSchema);

    const refund = await prisma.refundRequest.findFirst({
      where: { id: params.id, ...tenantWhere(user) },
      include: refundInclude,
    });
    if (!refund) throw notFound('Refund request not found in your university.');
    if (refund.status !== 'PENDING') {
      throw conflict(
        `This request was already ${refund.status.toLowerCase()} and can no longer be reviewed.`,
      );
    }

    const adminNote = body.adminNote?.trim() || null;

    if (body.decision === 'REJECTED') {
      const claimed = await prisma.refundRequest.updateMany({
        where: { id: refund.id, status: 'PENDING' },
        data: {
          status: 'REJECTED',
          adminNote,
          reviewedById: user.id,
          reviewedAt: new Date(),
        },
      });
      if (claimed.count === 0) {
        throw conflict('Another admin just reviewed this request. Refresh the queue.');
      }

      await auditLog({
        actorId: user.id,
        universityId: refund.universityId,
        action: 'REFUND_REJECTED',
        entity: 'RefundRequest',
        entityId: refund.id,
        metadata: {
          amount: refund.amount,
          reference: refund.reference,
          studentName: refund.student.user.name,
          note: adminNote,
        },
      });

      const updated = await prisma.refundRequest.findUniqueOrThrow({
        where: { id: refund.id },
        include: refundInclude,
      });
      return ok({ request: serializeRefund(updated) });
    }

    // Claim before touching money so two admins cannot double-pay a refund.
    const claimed = await prisma.refundRequest.updateMany({
      where: { id: refund.id, status: 'PENDING' },
      data: {
        status: 'APPROVED',
        adminNote,
        reviewedById: user.id,
        reviewedAt: new Date(),
      },
    });
    if (claimed.count === 0) {
      throw conflict('Another admin just reviewed this request. Refresh the queue.');
    }

    let payout: RefundResult;
    try {
      payout = await getPaymentProvider().initiateRefund({
        universityId: refund.universityId,
        studentProfileId: refund.studentId,
        amount: refund.amount,
        reason: refund.reason,
        actorId: user.id,
      });
    } catch (error) {
      // Payout failed: put the request back in the queue and record the attempt.
      await prisma.refundRequest.updateMany({
        where: { id: refund.id, status: 'APPROVED', reviewedById: user.id },
        data: { status: 'PENDING', adminNote: null, reviewedById: null, reviewedAt: null },
      });
      await auditLog({
        actorId: user.id,
        universityId: refund.universityId,
        action: 'REFUND_PAYOUT_FAILED',
        entity: 'RefundRequest',
        entityId: refund.id,
        metadata: {
          amount: refund.amount,
          reference: refund.reference,
          message: error instanceof Error ? error.message : 'Unknown payout error',
        },
      });
      throw error;
    }

    await auditLog({
      actorId: user.id,
      universityId: refund.universityId,
      action: 'REFUND_APPROVED',
      entity: 'RefundRequest',
      entityId: refund.id,
      metadata: {
        amount: refund.amount,
        reference: refund.reference,
        payoutReference: payout.reference,
        transactionId: payout.transactionId,
        provider: payout.provider,
        balanceAfter: payout.balance,
        studentName: refund.student.user.name,
        note: adminNote,
      },
    });

    const updated = await prisma.refundRequest.findUniqueOrThrow({
      where: { id: refund.id },
      include: refundInclude,
    });

    return ok({
      request: serializeRefund(updated),
      payout: {
        reference: payout.reference,
        transactionId: payout.transactionId,
        balance: payout.balance,
        provider: payout.provider,
      },
    });
  } catch (error) {
    return fail(error);
  }
}
