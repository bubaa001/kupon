/**
 * Response shapes for the student wallet API.
 *
 * These mirror `docs/API_CONTRACTS.md` and are shared by the App Router pages
 * (client components) and the typed API routes so the two can never drift.
 */
import type { RefundStatus, TxStatus, TxType } from '@/lib/constants';

export type StudentTx = {
  id: string;
  reference: string;
  amount: number;
  type: TxType;
  status: TxStatus;
  createdAt: string;
  vendor?: { name: string; code: string };
  channel: string;
  metadataSummary: string;
};

export type WalletStats = {
  todaySpent: number;
  weekSpent: number;
  mealsThisWeek: number;
  totalTopUps: number;
};

export type WalletData = {
  student: {
    name: string;
    studentId: string;
    course: string;
    year: number;
    phone: string;
    university: { name: string; code: string };
  };
  balance: number;
  stats: WalletStats;
  recentTransactions: StudentTx[];
};

export type TransactionsData = {
  transactions: StudentTx[];
  counts: { total: number; settled: number; pending: number; failed: number };
  totalIn: number;
  totalOut: number;
};

export type TopUpCreated = {
  transactionId: string;
  reference: string;
  status: 'PENDING';
  routeCode: string;
  message: string;
  aggregatorFee: number;
};

export type TopUpStatusData = {
  transaction: {
    id: string;
    reference: string;
    amount: number;
    status: TxStatus;
    network: string | null;
    createdAt: string;
    settledAt: string | null;
  };
  balance: number;
};

export type PaymentTokenCreated = {
  tokenId: string;
  token: string;
  code: string;
  expiresAt: string;
  expiresIn: number;
  student: { name: string; studentId: string };
  balance: number;
};

export type PaymentTokenTransaction = {
  vendor: { name: string; code: string } | null;
  amount: number;
  status: TxStatus;
  createdAt: string;
};

export type PaymentTokenStatusData = {
  status: 'ACTIVE' | 'USED' | 'EXPIRED';
  expiresAt: string;
  transaction?: PaymentTokenTransaction;
};

export type RefundRequestApi = {
  id: string;
  reference: string;
  amount: number;
  reason: string;
  status: RefundStatus;
  adminNote: string | null;
  createdAt: string;
  reviewedAt: string | null;
};

export type RefundsData = {
  requests: RefundRequestApi[];
  balance: number;
  eligibleAmount: number;
  hasPending: boolean;
};

export type RefundCreated = {
  request: RefundRequestApi;
  message: string;
};

export type StudentProfileData = {
  student: {
    id: string;
    name: string;
    studentId: string;
    course: string;
    year: number;
    phone: string;
    joinedAt: string;
  };
  university: { id: string; name: string; code: string; city: string };
  wallet: { balance: number; currency: string };
  stats: {
    totalTopUps: number;
    mealsCount: number;
    totalSpent: number;
    transactionsCount: number;
    pendingRefunds: number;
  };
};
