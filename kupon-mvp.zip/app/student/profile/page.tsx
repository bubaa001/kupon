'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import type { LucideIcon } from 'lucide-react';
import {
  BadgeCheck,
  BookOpen,
  Building2,
  CalendarDays,
  GraduationCap,
  Hash,
  LogOut,
  Phone,
  PlusCircle,
  RefreshCcw,
  ScanLine,
  ShieldCheck,
  Smartphone,
  Wallet,
} from 'lucide-react';
import { PageHeader } from '@/components/ui/page-header';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { ApiClientError, apiFetch } from '@/lib/client-api';
import { signOut } from '@/lib/logout';
import { formatDate, formatTZS } from '@/lib/utils';
import { ErrorState } from '../_components/error-state';
import type { StudentProfileData } from '../_lib/types';

function ProfileSkeleton() {
  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <Skeleton className="h-7 w-40" />
        <Skeleton className="h-4 w-64" />
      </div>
      <Skeleton className="h-[104px] w-full rounded-xl" />
      <Skeleton className="h-[180px] w-full rounded-2xl" />
      <div className="grid grid-cols-2 gap-2">
        {[0, 1, 2, 3].map((index) => (
          <Skeleton key={index} className="h-20 rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-[200px] w-full rounded-xl" />
    </div>
  );
}

function DetailRow({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 py-2.5">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
        <Icon className="h-4 w-4" aria-hidden />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
          {label}
        </p>
        <p className="truncate text-sm font-medium text-slate-800">{value}</p>
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const [data, setData] = useState<StudentProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await apiFetch<StudentProfileData>('/api/student/profile'));
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Imeshindikana kupakia wasifu wako.',
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading && !data) return <ProfileSkeleton />;

  if (!data) {
    return (
      <div className="space-y-5">
        <PageHeader
          eyebrow="Akaunti"
          title="Wasifu wangu"
          description="Taarifa zako za chuo, wallet na usalama."
        />
        <ErrorState message={error ?? 'Imeshindikana kupakia wasifu.'} onRetry={() => void load()} />
      </div>
    );
  }

  const { student, university, wallet, stats } = data;

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Akaunti"
        title="Wasifu wangu"
        description="Taarifa zako za chuo, wallet na usalama."
        actions={
          <Button variant="outline" size="sm" onClick={() => void load()} loading={loading}>
            <RefreshCcw aria-hidden />
            Sasisha
          </Button>
        }
      />

      <Card className="p-5">
        <div className="flex items-center gap-3">
          <Avatar name={student.name} size="lg" />
          <div className="min-w-0">
            <p className="truncate text-lg font-semibold tracking-tight text-slate-900">
              {student.name}
            </p>
            <p className="mt-0.5 truncate text-xs text-slate-500">{university.name}</p>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              <Badge variant="success" dot>
                <BadgeCheck className="h-3 w-3" aria-hidden />
                {university.code}
              </Badge>
              <Badge variant="neutral">
                {student.course} • Mwaka {student.year}
              </Badge>
            </div>
          </div>
        </div>
      </Card>

      <section className="balance-card p-5" aria-label="Salio la wallet">
        <div className="relative z-10 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-emerald-100/80">
              <Wallet className="h-3.5 w-3.5" aria-hidden />
              Salio lako
            </p>
            <p className="mt-2 text-[2rem] font-semibold leading-none tracking-tight tabular">
              {formatTZS(wallet.balance)}
            </p>
            <p className="mt-2 text-[11px] text-emerald-100/70">{wallet.currency} wallet</p>
          </div>
          <span className="shrink-0 rounded-full border border-white/15 bg-white/10 px-2.5 py-1 text-[10px] font-semibold text-emerald-100">
            {university.code}
          </span>
        </div>
        <div className="relative z-10 mt-5 grid grid-cols-2 gap-2">
          <Button
            asChild
            className="w-full bg-white px-3 text-sm text-primary-800 hover:bg-emerald-50 sm:px-6 sm:text-base"
          >
            <Link href="/student/topup">
              <PlusCircle aria-hidden />
              Weka pesa
            </Link>
          </Button>
          <Button
            asChild
            variant="secondary"
            className="w-full border border-white/20 bg-white/10 px-3 text-sm text-white shadow-none hover:bg-white/20 sm:px-6 sm:text-base"
          >
            <Link href="/student/pay">
              <ScanLine aria-hidden />
              Scan
            </Link>
          </Button>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-2">
        <Card className="p-4">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
            Top-ups
          </p>
          <p className="mt-1 text-base font-semibold tabular text-slate-900">{stats.totalTopUps}</p>
          <p className="text-[10px] text-slate-400">Zilizofanikiwa</p>
        </Card>
        <Card className="p-4">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
            Milo
          </p>
          <p className="mt-1 text-base font-semibold tabular text-slate-900">{stats.mealsCount}</p>
          <p className="text-[10px] text-slate-400">Zilizolipwa</p>
        </Card>
        <Card className="p-4">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
            Matumizi yote
          </p>
          <p className="mt-1 truncate text-base font-semibold tabular text-slate-900">
            {formatTZS(stats.totalSpent)}
          </p>
          <p className="text-[10px] text-slate-400">Tangu uanze</p>
        </Card>
        <Card className="p-4">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
            Refunds
          </p>
          <p className="mt-1 text-base font-semibold tabular text-slate-900">
            {stats.pendingRefunds}
          </p>
          <p className="text-[10px] text-slate-400">Zinasubiri admin</p>
        </Card>
      </div>

      <Card className="p-5">
        <p className="text-sm font-semibold text-slate-900">Taarifa za chuo</p>
        <div className="mt-2 divide-y divide-slate-100">
          <DetailRow icon={Hash} label="Namba ya mwanafunzi" value={student.studentId} />
          <DetailRow
            icon={Building2}
            label="Chuo"
            value={`${university.name}${university.city ? ` • ${university.city}` : ''}`}
          />
          <DetailRow icon={BookOpen} label="Kozi" value={student.course} />
          <DetailRow icon={GraduationCap} label="Mwaka wa masomo" value={`Mwaka ${student.year}`} />
          <DetailRow icon={Phone} label="Simu" value={student.phone} />
          <DetailRow
            icon={CalendarDays}
            label="Mwanachama tangu"
            value={formatDate(student.joinedAt, 'dd MMM yyyy')}
          />
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-violet-50 text-violet-600">
            <Smartphone className="h-4 w-4" aria-hidden />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-900">Sakinisha Kupon kwenye simu</p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500">
              Kupon ni Progressive Web App (PWA): unaiongeza kwenye home screen na kuitumia kama
              app ya kawaida — bila Play Store.
            </p>
          </div>
        </div>
        <div className="mt-3 space-y-2 rounded-xl bg-slate-50 p-3 text-[11px] leading-relaxed text-slate-600">
          <p>
            <span className="font-semibold text-slate-800">Android (Chrome):</span> menyu ⋮ →
            “Add to Home screen”.
          </p>
          <p>
            <span className="font-semibold text-slate-800">iPhone (Safari):</span> Share → “Add to
            Home Screen”.
          </p>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Badge variant="neutral">
            <ShieldCheck className="h-3 w-3" aria-hidden />
            Salama
          </Badge>
          <Badge variant="neutral">Scan &amp; order</Badge>
          <Badge variant="neutral">Salio la haraka</Badge>
        </div>
      </Card>

      <Card className="p-5">
        <p className="text-sm font-semibold text-slate-900">Kikao chako</p>
        <p className="mt-1 text-[11px] leading-relaxed text-slate-500">
          Ukitoka utahitaji msimbo wa OTP mpya ili kuingia tena. Usitoe namba yako ya OTP kwa mtu
          yeyote.
        </p>
        <Button
          variant="outline"
          className="mt-3 w-full border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
          onClick={() => void signOut()}
        >
          <LogOut aria-hidden />
          Toka (Sign out)
        </Button>
      </Card>
    </div>
  );
}
