/**
 * Payment rail abstraction.
 *
 * The student UI and wallet ledger only ever talk to this interface. Swapping
 * the mock Snippe implementation for Selcom, AzamPay, N-Card or a direct
 * Vodacom M-Pesa integration means adding a new class and changing
 * `getPaymentProvider()` in `lib/payments/index.ts` — no route or UI changes.
 */
export type TopUpRequest = {
  universityId: string;
  studentProfileId: string;
  amount: number;
  phone: string;
  network: string;
};

export type TopUpResult = {
  transactionId: string;
  reference: string;
  status: 'PENDING' | 'SETTLED' | 'FAILED';
  provider: string;
  routeCode: string;
  message: string;
  aggregatorFee: number;
};

export type RefundRequest = {
  universityId: string;
  studentProfileId: string;
  amount: number;
  reason: string;
  actorId?: string;
};

export type RefundResult = {
  transactionId: string;
  reference: string;
  status: 'PENDING' | 'SETTLED' | 'FAILED';
  provider: string;
  routeCode: string;
  balance: number;
};

export interface PaymentProvider {
  readonly name: string;
  initiateTopUp(input: TopUpRequest): Promise<TopUpResult>;
  settlePayment(
    transactionId: string,
  ): Promise<{ transactionId: string; status: string; balance?: number }>;
  initiateRefund(input: RefundRequest): Promise<RefundResult>;
}
