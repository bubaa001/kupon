export const ROLES = ['STUDENT', 'VENDOR', 'ADMIN', 'SUPER_ADMIN'] as const;
export type Role = (typeof ROLES)[number];

export const TX_TYPES = [
  'TOPUP',
  'PAYMENT',
  'REFUND',
  'ADJUSTMENT_CREDIT',
  'ADJUSTMENT_DEBIT',
] as const;
export type TxType = (typeof TX_TYPES)[number];

export const TX_STATUSES = ['PENDING', 'SETTLED', 'FAILED'] as const;
export type TxStatus = (typeof TX_STATUSES)[number];

export const REFUND_STATUSES = ['PENDING', 'APPROVED', 'REJECTED'] as const;
export type RefundStatus = (typeof REFUND_STATUSES)[number];

export const APPROVAL_STATUSES = ['PENDING', 'APPROVED', 'REJECTED'] as const;

export const MOBILE_NETWORKS = [
  { id: 'M-PESA', name: 'M-Pesa', short: 'Vodacom', color: '#E60000', prefix: '071, 074, 075, 076' },
  { id: 'TIGO_PESA', name: 'Tigo Pesa', short: 'Tigo', color: '#0B5CAD', prefix: '065, 067, 071' },
  { id: 'AIRTEL_MONEY', name: 'Airtel Money', short: 'Airtel', color: '#E40000', prefix: '068, 069, 078' },
  { id: 'HALOTEL', name: 'Halotel', short: 'Halotel', color: '#F58220', prefix: '061, 062' },
] as const;

export type MobileNetwork = (typeof MOBILE_NETWORKS)[number]['id'];

export const NETWORK_LABEL: Record<string, string> = {
  'M-PESA': 'M-Pesa',
  TIGO_PESA: 'Tigo Pesa',
  AIRTEL_MONEY: 'Airtel Money',
  HALOTEL: 'Halotel',
};

export const TX_TYPE_LABEL: Record<TxType, string> = {
  TOPUP: 'Top up',
  PAYMENT: 'Meal payment',
  REFUND: 'Refund',
  ADJUSTMENT_CREDIT: 'Admin credit',
  ADJUSTMENT_DEBIT: 'Admin debit',
};

export const STATUS_BADGE: Record<
  TxStatus,
  { label: string; variant: 'success' | 'warning' | 'danger' | 'neutral' }
> = {
  SETTLED: { label: 'Settled', variant: 'success' },
  PENDING: { label: 'Pending', variant: 'warning' },
  FAILED: { label: 'Failed', variant: 'danger' },
};

export const REFUND_BADGE: Record<
  RefundStatus,
  { label: string; variant: 'success' | 'warning' | 'danger' | 'neutral' }
> = {
  APPROVED: { label: 'Approved', variant: 'success' },
  PENDING: { label: 'Pending', variant: 'warning' },
  REJECTED: { label: 'Rejected', variant: 'danger' },
};

export const ROLE_LABEL: Record<Role, string> = {
  STUDENT: 'Student',
  VENDOR: 'Vendor',
  ADMIN: 'University admin',
  SUPER_ADMIN: 'Platform admin',
};

export const DEFAULT_FEES = {
  platformPercent: 2.5,
  aggregatorPercent: 1.5,
  universityShareOfFeePercent: 20,
};

export const TOPUP_AMOUNTS = [1000, 2000, 5000, 10000] as const;
export const MIN_TOPUP = 500;
export const MAX_TOPUP = 500_000;

export const QR_TTL_SECONDS = 120;
export const DEMO_MODE = process.env.DEMO_MODE !== 'false';

